package com.stratpoint.basedesignpatternguide.data.base

enum class Status {
    SUCCESS,
    ERROR
}
