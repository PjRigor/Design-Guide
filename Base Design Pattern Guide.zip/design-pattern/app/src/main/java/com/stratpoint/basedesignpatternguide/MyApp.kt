package com.stratpoint.basedesignpatternguide

import android.app.Application
import com.stratpoint.basedesignpatternguide.data.ManualInjection

class MyApp: Application() {

    override fun onCreate() {
        super.onCreate()
        // Initialize Manual Injection object class
        ManualInjection.initialize(this, BuildConfig.BASE_URL, BuildConfig.DEBUG)
    }
}