package com.stratpoint.basedesignpatternguide.data.base

import android.content.Context
import androidx.room.Room
import com.stratpoint.basedesignpatternguide.data.database.AppDatabase

object DatabaseBuilder {

    private const val DATABASE_NAME = "base_design_pattern_database"

    private lateinit var applicationContext: Context

    val appDatabase: AppDatabase by lazy { createDatabase() }

    fun initialize(context: Context) {
        applicationContext = context
    }

    private fun createDatabase() = Room.databaseBuilder(
        applicationContext,
        AppDatabase::class.java,
        DATABASE_NAME
    ).fallbackToDestructiveMigration().build()

}