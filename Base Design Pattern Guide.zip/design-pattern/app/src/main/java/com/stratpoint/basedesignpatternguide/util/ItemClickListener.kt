package com.stratpoint.basedesignpatternguide.util

interface ItemClickListener<T> {
    fun onItemClick(item: T)
}
