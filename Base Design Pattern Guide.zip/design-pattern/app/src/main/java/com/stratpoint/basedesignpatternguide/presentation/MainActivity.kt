package com.stratpoint.basedesignpatternguide.presentation

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.stratpoint.basedesignpatternguide.BuildConfig
import com.stratpoint.basedesignpatternguide.data.ManualInjection
import com.stratpoint.basedesignpatternguide.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private val viewBinding by lazy { ActivityMainBinding.inflate(layoutInflater) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(viewBinding.root)
    }
}