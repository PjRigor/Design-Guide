package com.stratpoint.basedesignpatternguide.data

import android.content.Context
import com.stratpoint.basedesignpatternguide.data.base.DatabaseBuilder
import com.stratpoint.basedesignpatternguide.data.base.RetrofitBuilder
import com.stratpoint.basedesignpatternguide.data.database.AppDatabase
import com.stratpoint.basedesignpatternguide.data.network.PopularMoviesService
import com.stratpoint.basedesignpatternguide.data.repository.movie_detail.MovieDetailRepository
import com.stratpoint.basedesignpatternguide.data.repository.popular_movies.PopularMoviesRepository
import retrofit2.Retrofit

object ManualInjection {

    private val retrofit: Retrofit by lazy { RetrofitBuilder.retrofit }
    private val appDatabase: AppDatabase by lazy { DatabaseBuilder.appDatabase }

    fun initialize(applicationContext: Context, baseUrl: String, isDebug: Boolean) {
        RetrofitBuilder.initialize(applicationContext, baseUrl, isDebug)
        DatabaseBuilder.initialize(applicationContext)
    }

    fun getPopularMoviesRepository() = PopularMoviesRepository(
        retrofit.create(PopularMoviesService::class.java),
        appDatabase
    )

    fun getMovieDetailRepository() = MovieDetailRepository(appDatabase)

}