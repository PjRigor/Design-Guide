package com.stratpoint.basedesignpatternguide.constant

enum class PaginationLoadingIndicator { NONE, SWIPE_REFRESH, MORE }